package com.yedam.java.ch01.object;

public class Car {

	public String model;
	
	public Car() {
		
	}
	
	public Car(String model) {
		this.model = model;
	}
}
